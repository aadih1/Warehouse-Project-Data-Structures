package warehouse;

public class PurchaseProduct {
    public static void main(String[] args) {
        StdIn.setFile(args[0]);
        StdOut.setFile(args[1]);
        int numProd = StdIn.readInt();
        Warehouse warehouse = new Warehouse();
	    while(!StdIn.isEmpty()){
            String string = StdIn.readString();
            if(string.equals("purchase")){
                int day = StdIn.readInt();
                int id = StdIn.readInt();
                int amount = StdIn.readInt();
                warehouse.purchaseProduct(id, day, amount);
            }else if(string.equals("add")){
                int day = Integer.parseInt(StdIn.readString());
                int id = Integer.parseInt(StdIn.readString());
                String name = StdIn.readString();
                int stock = Integer.parseInt(StdIn.readString());
                int demand = Integer.parseInt(StdIn.readString());
                warehouse.addProduct(id, name, stock, day, demand);
            }
    }
    StdOut.print(warehouse);
    }
}
