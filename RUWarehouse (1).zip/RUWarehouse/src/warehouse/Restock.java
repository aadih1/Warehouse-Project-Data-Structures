package warehouse;

public class Restock {
    public static void main(String[] args) {
        StdIn.setFile(args[0]);
        StdOut.setFile(args[1]);
        Warehouse w = new Warehouse();
	    int numProd = StdIn.readInt();
        while(!StdIn.isEmpty()){
            String s = StdIn.readString();
            if(s.equals ("restock")){
                int id = Integer.parseInt(StdIn.readString());
                int amount = Integer.parseInt(StdIn.readString());
                w.restockProduct(id, amount);
            }else if(s.equals ("add")){
                int day = Integer.parseInt(StdIn.readString());
                int id = Integer.parseInt(StdIn.readString());
                String name = StdIn.readString();
                int stock = Integer.parseInt(StdIn.readString());
                int demand = Integer.parseInt(StdIn.readString());
                w.addProduct(id, name, stock, day, demand);
        }
    }
    StdOut.print(w);
    }
}
