package warehouse;

/*
 * Use this class to test the deleteProduct method.
 */ 
public class DeleteProduct {
    public static void main(String[] args) {
        StdIn.setFile(args[0]);
        StdOut.setFile(args[1]);

        int numProd = StdIn.readInt();
        Warehouse w = new Warehouse();
        
        while(!StdIn.isEmpty()){
            String string = StdIn.readString();
            if (string.equals("delete")) {
                int id = Integer.parseInt(StdIn.readString());
                w.deleteProduct(id);
            }else if(string.equals("add")){
                int day = Integer.parseInt(StdIn.readString());
                int id = Integer.parseInt(StdIn.readString());
                String name = StdIn.readString();
                int stock = Integer.parseInt(StdIn.readString());
                int demand = Integer.parseInt(StdIn.readString());
    
                w.addProduct(id, name, stock, day, demand);
            }
    }
    StdOut.print(w);
}
}